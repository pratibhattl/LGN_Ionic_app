export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyB54Aeu_nkeKYQp2mi2EazMuUibHpSlOqA",
  authDomain: "lgnserver-420b9.firebaseapp.com",
  projectId: "lgnserver-420b9",
  storageBucket: "lgnserver-420b9.appspot.com",
  messagingSenderId: "484708690301",
  appId: "1:484708690301:web:6052eb070ddc8602a2c414",
  measurementId: "G-YV34EB3FMC"
  },
};
