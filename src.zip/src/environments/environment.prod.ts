export const environment = {
  production: true,
  apiUrl: "http://13.232.69.201:8080/api/"
};
