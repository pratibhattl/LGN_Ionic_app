import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcomplain',
  templateUrl: './addcomplain.page.html',
  styleUrls: ['./addcomplain.page.scss'],
})
export class AddcomplainPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
