import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkmail',
  templateUrl: './checkmail.page.html',
  styleUrls: ['./checkmail.page.scss'],
})
export class CheckmailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
